/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Hierarchy",url:"inherits.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions.html#index_b"},
{text:"d",url:"functions.html#index_d"},
{text:"g",url:"functions.html#index_g"},
{text:"h",url:"functions.html#index_h"},
{text:"i",url:"functions.html#index_i"},
{text:"m",url:"functions.html#index_m"},
{text:"n",url:"functions.html#index_n"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"q",url:"functions.html#index_q"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"u",url:"functions.html#index_u"},
{text:"w",url:"functions.html#index_w"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func.html#index_b"},
{text:"d",url:"functions_func.html#index_d"},
{text:"g",url:"functions_func.html#index_g"},
{text:"i",url:"functions_func.html#index_i"},
{text:"m",url:"functions_func.html#index_m"},
{text:"o",url:"functions_func.html#index_o"},
{text:"p",url:"functions_func.html#index_p"},
{text:"q",url:"functions_func.html#index_q"},
{text:"s",url:"functions_func.html#index_s"},
{text:"t",url:"functions_func.html#index_t"},
{text:"u",url:"functions_func.html#index_u"},
{text:"w",url:"functions_func.html#index_w"}]},
{text:"Variables",url:"functions_vars.html"},
{text:"Related Functions",url:"functions_rela.html"}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"File Members",url:"globals.html",children:[
{text:"All",url:"globals.html"},
{text:"Functions",url:"globals_func.html"},
{text:"Variables",url:"globals_vars.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
