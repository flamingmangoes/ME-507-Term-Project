#include <Arduino.h>
#include <SPI.h>

#include "Controller.h"
#include "Shares.h"

Controller::Controller(void)
    : J(0.001712) // kg * m^2, moment of inertia for the motor and load
{
    Kp = 2;
    Ki = 2;
    Kd = 2;
    dt = 0.001;
    last_torque_cmd = 0.0;
    omega_sum = 0.0;
}

Controller::Controller(uint8_t Kp_, uint8_t Ki_, uint8_t Kd_)
    : J(0.001712) // kg * m^2, moment of inertia for the motor and load
{
    Kp = Kp_;
    Ki = Ki_;
    Kd = Kd_;
    dt = 0.001;
    last_torque_cmd = 0.0;
    omega_sum = 0.0;
}

float Controller::calculate_omega(float torque_cmd_)
{
    float alpha = torque_cmd_ / J; // angular acceleration
    // numerically integrate having saved the last value of torque_cmd_ to find omega?

}

float Controller::calculate_action(float speed_setpt_, float speed_actual_)
{
    float error = speed_setpt_ - speed_actual_;
    // Implement PID control logic here using Kp, Ki, Kd and the error
}

void Controller::set_gains_SPI(uint8_t Kp_NEW, uint8_t Ki_NEW, uint8_t Kd_NEW)
{
    Kp = Kp_NEW;
    Ki = Ki_NEW;
    Kd = Kd_NEW;
}
