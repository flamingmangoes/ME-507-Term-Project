#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include <Arduino.h>
#include <SPI.h>

class Controller 
{
    protected:
        
        uint8_t Kp;
        uint8_t Ki;
        uint8_t Kd;
        const float J; // moment of inertia
        float dt; // time step for numerical integration
        float last_torque_cmd; // for numerical integration
        float omega_sum; // for numerical integration

    public:
        
        Controller(void);
        Controller(uint8_t Kp_, uint8_t Ki_, uint8_t Kd_);

        float calculate_omega(float torque_cmd_);
        float calculate_action(float speed_setpt_, float speed_actual_);
        void set_gains_SPI(uint8_t Kp_NEW, uint8_t Ki_NEW, uint8_t Kd_NEW); 
};

#endif