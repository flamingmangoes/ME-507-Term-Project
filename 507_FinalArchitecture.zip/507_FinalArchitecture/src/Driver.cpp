#include <Arduino.h>
#include <SPI.h>

#include "Driver.h"
#include "Shares.h"

SPIClass vspi(VSPI);

Driver::Driver(void)
    : SAMPLE_MS(100)  // sample window (100 ms)
{
    data16 = 0;
    msb = 0;
    lsb = 0;
    lastState = LOW;
    currentState = LOW;
    edgeCount = 0;
    lastSample = 0;;
    now = 0;
    dt = 0;
    freq_calc = 0;
    rpm_calc = 0;
    PIN_SCLK = 18;
    PIN_MISO = 19;
    PIN_MOSI = 23;
    PIN_SCS = 5;
    PIN_EN = 13;
    PIN_CLKIN = 24;
    PIN_FGOUT = 25;
    PIN_FAULTn = 26;
    PIN_LOCKn = 27;

    // Initialize pins
    pinMode(PIN_SCS, OUTPUT);
    pinMode(PIN_EN, OUTPUT);
    pinMode(PIN_FGOUT, INPUT);
    pinMode(PIN_FAULTn, INPUT);
    pinMode(PIN_LOCKn, INPUT);

    // Initialize gains and such
    drv_write(0x00, 0x2000); // set AGSETPT to 12Hz
    Serial.print("0x00 expected: 0x2000, actual:"); Serial.println(drv_read(0x00), HEX);

    drv_write(0x04, 0x0600); // Set AUTOADV and AUTOGAIN 
    Serial.print("0x04 expected: 0x0600, actual:"); Serial.println(drv_read(0x04), HEX);

    drv_write(0x06, 0x0004); // Set FILK1 to 4 automatically
    Serial.print("0x06 expected: 0x0004, actual:"); Serial.println(drv_read(0x06), HEX);

    drv_write(0x07, 0x0001); // Set FILK2 to 1 automatically
    Serial.print("0x07 expected: 0x0001, actual:"); Serial.println(drv_read(0x07), HEX);

    drv_write(0x08, 0x0008); // Set COMPK1 to 8 automatically
    Serial.print("0x08 expected: 0x0008, actual:"); Serial.println(drv_read(0x08), HEX);

    drv_write(0x09, 0x2002); // Set COMPK2 to 2 automatically and set AASETPT to 12 Hz
    Serial.print("0x09 expected: 0x0002, actual:"); Serial.println(drv_read(0x09), HEX);

    // Initialize SPI peripheral
    vspi.begin(PIN_SCLK, PIN_MISO, PIN_MOSI, -1);

}

Driver::Driver(uint8_t SCLK, uint8_t MISO, uint8_t MOSI, uint8_t SCS, uint8_t EN, uint8_t FGOUT, uint8_t FAULTn, uint8_t LOCKn, uint8_t CLKIN)
    : SAMPLE_MS(100)  // sample window (100 ms)
{
    data16 = 0;
    msb = 0;
    lsb = 0;
    lastState = LOW;
    currentState = LOW;
    edgeCount = 0;
    lastSample = 0;;
    now = 0;
    dt = 0;
    freq_calc = 0;
    rpm_calc = 0;
    PIN_SCLK = SCLK;
    PIN_MISO = MISO;
    PIN_MOSI = MOSI;
    PIN_SCS = SCS;
    PIN_EN = EN;
    PIN_CLKIN = CLKIN;
    PIN_FGOUT = FGOUT;
    PIN_FAULTn = FAULTn;
    PIN_LOCKn = LOCKn;
    FILK1 = 4;
    FILK2 = 1;
    COMPK1 = 8;
    COMPK2 = 2;

    // Initialize pins
    pinMode(PIN_SCS, OUTPUT);
    pinMode(PIN_EN, OUTPUT);
    pinMode(PIN_FGOUT, INPUT);
    pinMode(PIN_FAULTn, INPUT);
    pinMode(PIN_LOCKn, INPUT);

    // Initialize gains and such
    drv_write(0x00, 0x2000); // set AGSETPT to 12Hz
    Serial.print("0x00 expected: 0x2000, actual:"); Serial.println(drv_read(0x00), HEX);

    drv_write(0x04, 0x0600); // Set AUTOADV and AUTOGAIN 
    Serial.print("0x04 expected: 0x0600, actual:"); Serial.println(drv_read(0x04), HEX);

    drv_write(0x06, FILK1); // Set FILK1 to 4 automatically
    Serial.print("0x06 expected: 0x0004, actual:"); Serial.println(drv_read(0x06), HEX);

    drv_write(0x07, FILK2); // Set FILK2 to 1 automatically
    Serial.print("0x07 expected: 0x0001, actual:"); Serial.println(drv_read(0x07), HEX);

    drv_write(0x08, COMPK1); // Set COMPK1 to 8 automatically
    Serial.print("0x08 expected: 0x0008, actual:"); Serial.println(drv_read(0x08), HEX);

    drv_write(0x09, (0b0010 << 12) | COMPK2); // Set COMPK2 to 2 automatically and set AASETPT to 12 Hz
    Serial.print("0x09 expected: 0x2002, actual:"); Serial.println(drv_read(0x09), HEX);


    // Initialize SPI peripheral
    vspi.begin(PIN_SCLK, PIN_MISO, PIN_MOSI, -1);
}

Driver::Driver(uint8_t SCLK, uint8_t MISO, uint8_t MOSI, uint8_t SCS, uint8_t EN, uint8_t FGOUT, uint8_t FAULTn, uint8_t LOCKn, uint8_t CLKIN, uint8_t FILK1_, uint8_t FILK2_, uint8_t COMPK1_, uint8_t COMPK2_)
    : SAMPLE_MS(100)  // sample window (100 ms)
{
    data16 = 0;
    msb = 0;
    lsb = 0;
    lastState = LOW;
    currentState = LOW;
    edgeCount = 0;
    lastSample = 0;;
    now = 0;
    dt = 0;
    freq_calc = 0;
    rpm_calc = 0;
    PIN_SCLK = SCLK;
    PIN_MISO = MISO;
    PIN_MOSI = MOSI;
    PIN_SCS = SCS;
    PIN_EN = EN;
    PIN_CLKIN = 24;
    PIN_FGOUT = FGOUT;
    PIN_FAULTn = FAULTn;
    PIN_LOCKn = LOCKn;
    FILK1 = FILK1_;
    FILK2 = FILK2_;
    COMPK1 = COMPK1_;
    COMPK2 = COMPK2_;

    // Initialize pins
    pinMode(PIN_SCS, OUTPUT);
    pinMode(PIN_EN, OUTPUT);
    pinMode(PIN_FGOUT, INPUT);
    pinMode(PIN_FAULTn, INPUT);
    pinMode(PIN_LOCKn, INPUT);
    ledcSetup(0, 0, 8); // configure timer for the channel
    ledcAttachPin(PIN_CLKIN, 0); // attach the channel to the GPIO to be controlled

    // Initialize gains and such
    drv_write(0x00, 0x2000); // set AGSETPT to 12Hz
    Serial.print("0x00 expected: 0x2000, actual:"); Serial.println(drv_read(0x00), HEX);

    drv_write(0x04, 0x0600); // Set AUTOADV and AUTOGAIN 
    Serial.print("0x04 expected: 0x0600, actual:"); Serial.println(drv_read(0x04), HEX);

    drv_write(0x06, FILK1); // Set FILK1 to 4 automatically
    Serial.print("0x06 expected: 0x0004, actual:"); Serial.println(drv_read(0x06), HEX);

    drv_write(0x07, FILK2); // Set FILK2 to 1 automatically
    Serial.print("0x07 expected: 0x0001, actual:"); Serial.println(drv_read(0x07), HEX);

    drv_write(0x08, COMPK1); // Set COMPK1 to 8 automatically
    Serial.print("0x08 expected: 0x0008, actual:"); Serial.println(drv_read(0x08), HEX);

    drv_write(0x09, (0b0010 << 12) | COMPK2); // Set COMPK2 to 2 automatically and set AASETPT to 12 Hz
    Serial.print("0x09 expected: 0x2002, actual:"); Serial.println(drv_read(0x09), HEX);


    // Initialize SPI peripheral
    vspi.begin(PIN_SCLK, PIN_MISO, PIN_MOSI, -1);
}

void Driver::drv_write(uint8_t addr7, uint16_t message) 
{
    
    vspi.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0)); // 1 MHz, Mode 0
    scs_begin();
    delayMicroseconds(1); // Setup time for SCS
    vspi.transfer((0u << 7) | (addr7 & 0x7F));
    vspi.transfer((uint8_t)(message >> 8));
    vspi.transfer((uint8_t)(message & 0xFF));
    delayMicroseconds(1); // Hold time for data
    scs_end();
    vspi.endTransaction();
    delayMicroseconds(5); // Recovery time between transactions

}

uint16_t Driver::drv_read(uint8_t addr7)  // make sure this does the send READ bit over SDATAI then reads the next 16 bits over SDATO
{
    vspi.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0)); // Same mode as write
    scs_begin();
    delayMicroseconds(1); // Setup time for SCS
    vspi.transfer((1u << 7) | (addr7 & 0x7F));
    msb = vspi.transfer(0x00);
    lsb = vspi.transfer(0x00);
    delayMicroseconds(1); // Hold time for data
    scs_end();
    vspi.endTransaction();
    delayMicroseconds(5); // Recovery time
    return (uint16_t(msb) << 8) | lsb;
}

void Driver::cmd_speed_SPI(float SPEED_CMD)
{
    // Convert speed command to 12-bit value (example conversion, adjust as needed)
    // max RPM is 2760, can change later
    float duty_cycle = ( SPEED_CMD / 2760 ) * 4095; 
    drv_write(0x0B, duty_cycle); // Write to the speed command register
    // BUG why is this not working?
}

void Driver::cmd_speed_PWM(float SPEED_CMD)
{
    double freq = SPEED_CMD / 15;
    ledcWriteTone(0, freq); // Set the frequency of the PWM signal on channel 0

}

// float Driver::read_FGOUT(void)
// {
//     uint16_t fgout_value = drv_read(0x0B); // Read from the FGOUT register (example address)
//     return float(fgout_value) / 100.0; // Example conversion, adjust as needed
// }

void Driver::set_gains_CLKIN(uint8_t FILK1_NEW, uint8_t FILK2_NEW, uint8_t COMPK1_NEW, uint8_t COMPK2_NEW)
{
    drv_write(0x06, FILK1_NEW); // Set FILK1 to 4 automatically
    Serial.print("0x06 expected: 0x0004, actual:"); Serial.println(drv_read(0x06), HEX);

    drv_write(0x07, FILK2_NEW); // Set FILK2 to 1 automatically
    Serial.print("0x07 expected: 0x0001, actual:"); Serial.println(drv_read(0x07), HEX);

    drv_write(0x08, COMPK1_NEW); // Set COMPK1 to 8 automatically
    Serial.print("0x08 expected: 0x0008, actual:"); Serial.println(drv_read(0x08), HEX);

    drv_write(0x09, (0b0010 << 12) | COMPK2_NEW); // Set COMPK2 to 2 automatically and set AASETPT to 12 Hz
    Serial.print("0x09 expected: 0x2002, actual:"); Serial.println(drv_read(0x09), HEX);
}