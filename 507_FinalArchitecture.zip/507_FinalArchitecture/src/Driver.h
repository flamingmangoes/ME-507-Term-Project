#ifndef _DRIVER_H_
#define _DRIVER_H_

#include <Arduino.h>
#include <SPI.h>

class Driver 
{
    protected:

        uint16_t data16;
        uint8_t msb;
        uint8_t lsb;
        bool lastState;
        bool currentState;
        unsigned long edgeCount;
        unsigned long lastSample;
        unsigned long now;
        float dt;
        float freq_calc;
        float rpm_calc;
        uint8_t PIN_SCLK;
        uint8_t PIN_MISO;
        uint8_t PIN_MOSI;
        uint8_t PIN_SCS;
        uint8_t PIN_EN;
        uint8_t PIN_CLKIN;
        uint8_t PIN_FGOUT;
        uint8_t PIN_FAULTn;
        uint8_t PIN_LOCKn;
        const uint8_t SAMPLE_MS;
        uint8_t FILK1;
        uint8_t FILK2;
        uint8_t COMPK1;
        uint8_t COMPK2; 

    public:

        Driver(void);
        Driver(uint8_t SCLK, uint8_t MISO, uint8_t MOSI, uint8_t SCS, uint8_t EN, uint8_t FGOUT, uint8_t FAULTn, uint8_t LOCKn, uint8_t CLKIN);
        Driver(uint8_t SCLK, uint8_t MISO, uint8_t MOSI, uint8_t SCS, uint8_t EN, uint8_t FGOUT, uint8_t FAULTn, uint8_t LOCKn, uint8_t CLKIN, uint8_t FILK1_, uint8_t FILK2_, uint8_t COMPK1_, uint8_t COMPK2_);

        void scs_begin(void) 
        { 
            digitalWrite(PIN_SCS, HIGH);  
        }

        void scs_end(void)
        { 
            digitalWrite(PIN_SCS, LOW);  
        }

        void enable(void)
        { 
            digitalWrite(PIN_EN, HIGH);  // DRV8308 uses active HIGH for SCS
        }

        void disable(void)
        { 
            digitalWrite(PIN_EN, LOW);  // DRV8308 uses active HIGH for SCS
        }

        void drv_write(uint8_t spdmode, uint16_t message);
        uint16_t drv_read(uint8_t addr7);

        void cmd_speed_SPI(float SPEED_CMD); // better to put these tasks in main.cpp or define as tasks here?
        void cmd_speed_PWM(float SPEED_CMD);
        float read_FGOUT(void);
        void set_gains_CLKIN(uint8_t FILK1_NEW, uint8_t FILK2_NEW, uint8_t COMPK1_NEW, uint8_t COMPK2_NEW);
};

#endif