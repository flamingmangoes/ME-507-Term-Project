#ifndef _SHARES_H_
#define _SHARES_H_  

#include "taskqueue.h"
#include "taskshare.h"

extern Queue<float> torque_cmd;
extern Share<float> speed_setpt;
extern Share<float> speed_cmd;
extern Share<float> speed_actual;
extern Queue<uint8_t> FILK1_SHARE;
extern Queue<uint8_t> FILK2_SHARE;
extern Queue<uint8_t> COMPK1_SHARE;
extern Queue<uint8_t> COMPK2_SHARE;
extern Queue<uint8_t> Kp_SHARE;
extern Queue<uint8_t> Ki_SHARE;
extern Queue<uint8_t> Kd_SHARE;

#endif