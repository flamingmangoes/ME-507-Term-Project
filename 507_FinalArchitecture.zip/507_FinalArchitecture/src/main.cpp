#include <Arduino.h>
#include <SPI.h>
#include "Shares.h"
#include "Driver.h"
#include "Controller.h"
#include "taskshare.h"
#include "taskqueue.h"

Queue<float> torque_cmd (2, "Torque Command");
Share<float> speed_setpt ("Speed Setpoint");
Share<float> speed_cmd ("Speed Command"); 
Share<float> speed_actual ("Speed Actual");
Queue<uint8_t> FILK1_SHARE (2, "FILK1");
Queue<uint8_t> FILK2_SHARE (2, "FILK2"); 
Queue<uint8_t> COMPK1_SHARE (2, "COMPK1");
Queue<uint8_t> COMPK2_SHARE (2, "COMPK2");
Queue<uint8_t> Kp_SHARE (2, "Kp");
Queue<uint8_t> Ki_SHARE (2, "Ki");
Queue<uint8_t> Kd_SHARE (2, "Kd");